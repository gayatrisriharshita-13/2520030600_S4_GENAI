
import os
import time
from dotenv import load_dotenv
from google import genai
from google.genai import errors

# Load API key
load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("Gemini API key not found!")

# Initialize Gemini client
client = genai.Client(api_key=api_key)

question = "What is Artificial Intelligence? Explain in simple words."

# Try up to 3 times
for attempt in range(3):
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents=question
        )

        print("\nLLM Response:")
        print(response.text)
        break

    except errors.APIError as e:
        if e.code in [429, 500, 503] and attempt < 2:
            wait_time = 2 ** (attempt + 1)
            print(f"Server busy. Retrying in {wait_time} seconds...")
            time.sleep(wait_time)
        else:
            print("Gemini API Error:", e)
            break

client.close()
